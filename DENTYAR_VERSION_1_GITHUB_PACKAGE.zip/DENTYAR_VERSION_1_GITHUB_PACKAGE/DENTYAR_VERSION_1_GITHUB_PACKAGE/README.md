# DENTYAR VERSION 1 — Experimental GitHub Package

مرجع بصری و عملکردی این بسته، فایل آزمایشی DENTYAR VERSION 1 است.

## ساختار
- www/index.html — نسخه آزمایشی کامل رابط و منطق فعلی
- www/app.js — محل لایه ماژولار آینده
- www/database.js — محل لایه دیتابیس ماژولار آینده
- www/manifest.json
- capacitor.config.json
- package.json
- .github/workflows/build-apk.yml

## هدف
این بسته برای تست اولیه در GitHub و ساخت APK آزمایشی تهیه شده است و هنوز «نسخه نهایی محصول» محسوب نمی‌شود.
