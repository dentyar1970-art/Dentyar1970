/* DENTYAR VERSION 1
   Experimental package: application logic is currently bundled in www/index.html.
   This file is reserved for the modular app layer in the next build phase.
*/
