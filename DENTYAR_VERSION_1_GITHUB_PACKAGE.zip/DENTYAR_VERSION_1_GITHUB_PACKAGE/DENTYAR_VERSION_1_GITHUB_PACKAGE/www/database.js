/* DENTYAR VERSION 1
   Database logic is currently bundled in www/index.html for this experimental build.
   The IndexedDB schema in the experimental application remains the source of truth.
*/
